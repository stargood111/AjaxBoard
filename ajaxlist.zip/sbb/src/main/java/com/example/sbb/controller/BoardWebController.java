package com.example.sbb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.sbb.service.BoardService;

@Controller
public class BoardWebController {
	@Autowired
	private BoardService service; 
	
	@RequestMapping("/board") //웹에서 들어오는 url 맵핑주소
	public String doBoard(Model model) { //doBoard.jsp를 부르는 메소드
//		model.addAttribute("list", service.getList());
		return "views/board"; //리턴값 WEB-INF-views-home.jsp
	}
	@RequestMapping("/boarddetail") //웹에서 들어오는 url 맵핑주소
	public String doBoard2(Model model) { //boarddetail.jsp를 부르는 메소드
		return "views/boarddetail"; //리턴값 WEB-INF-views-home.jsp
	}
}
//
//	@RequestMapping("/board2") //웹에서 들어오는 url 맵핑주소
//	public String doBoard2(Model model) { //home.jsp를 부르는 메소드
//		model.addAttribute("serarchList", service.getList());
//		return "views/board1"; //리턴값 WEB-INF-views-home.jsp
//	}
//	@RequestMapping("/home") //웹에서 들어오는 url 맵핑주소
//	public String doHome2() { //home.jsp를 부르는 메소드
//		return "views/home2"  ; //리턴값 WEB-INF-views-home.jsp
//	}
//}
//	@RequestMapping("/date")
//		public String datehome() {
//		return "views/datehome";
//	}
//	
//	@RequestMapping("/jsp")
//	public String doHome2() {
//		return "views/home2";
//	}
//	@RequestMapping("")
//	public String doHome2() {
//		return "WEB-INF/views/home2";
//	}



