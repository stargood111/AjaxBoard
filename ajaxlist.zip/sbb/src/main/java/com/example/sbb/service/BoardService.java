package com.example.sbb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.sbb.dao.BoardDao;
import com.example.sbb.dto.BoardDto;

@org.springframework.stereotype.Service
public class BoardService {
	
	@Autowired
	private BoardDao boardDao;
	
	public List<BoardDto> getList() {
		
		return boardDao.listDao();
		
		// 2.BoardDao에 listDao 호출
		// 6.BoardDao listdao()에서 호출한 dto listDao()에서 결과값 반환
	}
	
	public BoardDto getDetail(String pnum) {
		return boardDao.detailDao(pnum);
	 }
	
	public void addBoard(String pnum, String pname,String pcontent) {
		boardDao.writeDao(pnum, pname, pcontent);//글쓰기
	 }
	
	public void deleteBoard(String pnum) {
		boardDao.deleteDao(pnum);//글쓰기
	 }
	
	public void updateBoard(String pname, String pcontent, String pnum) {
		boardDao.modifyDao(pnum, pname, pcontent);//글쓰기
	 }
	
	
	
}

