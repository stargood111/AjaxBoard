package com.example.sbb.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.sbb.dto.BoardDto;

@Mapper
public interface BoardDao {

		
	//q_board 조작 dao
	public List<BoardDto> listDao();//리스트 가져오기
	//3. mapper 에 listDao 호춣
	//5. List형태로 DTO받음
	public BoardDto detailDao(String pnum);//게시판 글보기
	public void writeDao(String pnum, String pname, String pcontent);//글쓰기
	public void deleteDao(String pnum);//글지우기
	public void modifyDao(String pname, String pcontent, String pnum);//글 수정
}

