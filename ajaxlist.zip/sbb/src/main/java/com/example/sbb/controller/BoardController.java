package com.example.sbb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.ParsedSql;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.sbb.dao.BoardDao;
import com.example.sbb.dto.BoardDto;
import com.example.sbb.service.BoardService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class BoardController {
	@Autowired
	private BoardService service; 

	@RequestMapping("/boa") //웹에서 들어오는 url 맵핑주소
	public List<BoardDto> doBoard() { //BoardDto //이 구분은 무엇? 함수를 실행?
		return service.getList(); //반환값 service에 list를 불러옴 
		//1.service에 getList() 호출 
	}
	@RequestMapping("/boa2") //웹에서 들어오는 url 맵핑주소
	public String doDetail() { //home.jsp를 부르는 메소드
		BoardDto a = service.getDetail("4");
		System.out.println(a.getPname());
		
		return ""; 
				//service.getDetail(pnum);	
		}
}
//	@RequestMapping("/boa3") //웹에서 들어오는 url 맵핑ddd주소
//	public void doAdd(String pnum, String pname,String pcontent) { //home.jsp를 부르는 메소드
//		
//		BoardDto a = service.addBoard(4,"홍길동","안녕하세요 홍길동입니다"); 
//	}
//}

//service.addBoard("4","홍길동","안녕하세요 홍길동입니다");
//
//service.deleteBoard("4");
//	
//service.updateBoard("4","홍길동","반갑습니다 홍길동입니다");
