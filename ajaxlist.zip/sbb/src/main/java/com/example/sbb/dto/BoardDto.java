package com.example.sbb.dto;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Data 
//GETTER , SETTER 만들어줌
@NoArgsConstructor
///기본 생성자를 만들어줌
@AllArgsConstructor
//필드에 쓴 모든생성자만 만들어줌
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY) 
public class BoardDto {

	public Integer getPnum() {
		return pnum;
	}
	public void setPnum(Integer pnum) {
		this.pnum = pnum;
	}
	public String getPtitle() {
		return ptitle;
	}
	public void setPtitle(String ptitle) {
		this.ptitle = ptitle;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPcontent() {
		return pcontent;
	}
	public void setPcontent(String pcontent) {
		this.pcontent = pcontent;
	}
	public Date getPdate() {
		return pdate;
	}
	public void setPdate(Date pdate) {
		this.pdate = pdate;
	}
	private Integer pnum; //글번호  //
	private String ptitle; //글제목
	private String pname; //글쓴이
	private String pcontent; //글내용
	private Date pdate; //글쓴날짜
	
	
	
}
